<!-- Footer -->
<footer class="sticky-footer bg-white">
<div class="container my-auto">
  <div class="copyright text-center my-auto">
    <span>Copyright &copy; 2019 <a href="https://www.mercubuana.ac.id/id" target="_blank"> Universitas Mercu Buana.</a></span>
  </div>
</div>
</footer>
<!-- End of Footer -->